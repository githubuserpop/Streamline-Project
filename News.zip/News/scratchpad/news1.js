const apiKey = "a517682f1cb148639ff9cf431afff950";

function clock(){
    window.rt=1000;r=0;
    document.getElementById('t-0').textContent=new Date().toLocaleDateString(); // today
    var m=setInterval(function(){
        if(r>84600){clearInterval(m);}
        r++;
        document.getElementById('t-2').textContent=new Date().toLocaleTimeString(); // clock
    }, window.rt);
}

function showLoading() {
    document.getElementById('newsContainer').innerHTML = '<div class="loading">Loading news...</div>';
}

function updateTitle(category) {
    const title = category.charAt(0).toUpperCase() + category.slice(1);
    document.getElementById('categoryTitle').textContent = `${title} News`;
}

async function fetchNews(category = 'general', country = 'us') {
    showLoading();
    updateTitle(category);
    
    let url;
    if (category === 'general') {
        url = `https://newsapi.org/v2/top-headlines?country=${country}&apiKey=${apiKey}`;
    } else {
        url = `https://newsapi.org/v2/top-headlines?country=${country}&category=${category}&apiKey=${apiKey}`;
    }

    try {
        const response = await fetch(url);
        const data = await response.json();
        displayNews(data.articles);
    } catch (error) {
        console.error("Error fetching news:", error);
        document.getElementById('newsContainer').innerHTML = '<div class="loading">Error loading news. Please try again later.</div>';
    }
}

async function fetchSubCategory(category, subCategory) {
    showLoading();
    updateTitle(`${subCategory} ${category}`);
    
    const url = `https://newsapi.org/v2/everything?q=${subCategory}&apiKey=${apiKey}`;
    
    try {
        const response = await fetch(url);
        const data = await response.json();
        displayNews(data.articles);
    } catch (error) {
        console.error("Error fetching news:", error);
        document.getElementById('newsContainer').innerHTML = '<div class="loading">Error loading news. Please try again later.</div>';
    }
}

function displayNews(articles) {
    const newsContainer = document.getElementById("newsContainer");
    newsContainer.innerHTML = "";

    articles.forEach(article => {
        const articleDiv = document.createElement("div");
        articleDiv.classList.add("news-article");
        articleDiv.innerHTML = `
            <img src="${article.urlToImage || '/api/placeholder/400/320'}" alt="News Image" onerror="this.src='/api/placeholder/400/320'">
            <h3>${article.title}</h3>
            <p>${article.description || 'No description available'}</p>
            <a href="${article.url}" target="_blank">Read more</a>
        `;
        newsContainer.appendChild(articleDiv);
    });

}

// Load general news when page loads
