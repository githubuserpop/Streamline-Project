const apiKey = "7ce7c6e29ec54f9a890596e4601ecdf1"; // Replace with your actual API key
const url = `https://newsapi.org/v2/everything?q=apple&from=2025-02-22&to=2025-02-22&sortBy=popularity&apiKey=${apiKey}`;

async function fetchNews() {
    try {
        const response = await fetch(url);
        const data = await response.json();

        const newsContainer = document.getElementById("newsContainer");
        newsContainer.innerHTML = ""; // Clear previous content

        data.articles.forEach(article => {
            const articleDiv = document.createElement("div");
            articleDiv.classList.add("news-article");

            articleDiv.innerHTML = `
                <h3>${article.title}</h3>
                <img src="${article.urlToImage}" alt="News Image" style="max-width:100%; height:auto;">
                <p>${article.description}</p>
                <a href="${article.url}" target="_blank">Read more</a>
            `;

            newsContainer.appendChild(articleDiv);
        });
    } catch (error) {
        console.error("Error fetching news:", error);
    }
}

// Call function when page loads
fetchNews();
